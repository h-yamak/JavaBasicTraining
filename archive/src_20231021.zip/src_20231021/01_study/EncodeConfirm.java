public class EncodeConfirm {
    public static void main(String[] args) {
        System.out.println(System.getProperty("file.encoding"));
    }
}
